const STORAGE_KEY = 'memphis-fleet-desktop-v1';
const now = Date.now();
const seed = {
  cash: 400000,
  vehicles: [
    {id:'v222',name:'Daimler S-Class W222',plate:'MEM222',purchase:4500000,market:4700000,scrap:2350000,status:'personal',photo:'',note:'Выкуплен обратно после продажи',advert:''},
    {id:'vrs6',name:'Horen RS6',plate:'3RIC274',purchase:3550000,market:4200000,scrap:3350000,status:'available',photo:'assets/rs6.png',note:'Premium • 1 ур. двигателя',advert:'ФТ, топ для дальнобойщика. DS: dexenometriya'},
    {id:'vlc',name:'Tatsuro Land Cruiser 200',plate:'2GFQ212',purchase:1250000,market:1550000,scrap:1000000,status:'available',photo:'assets/lc200.png',note:'Premium • без тюнинга',advert:'ФТ, топ для дальнобойщика. DS: dexenometriya'}
  ],
  rentals: [],
  rentalHistory: [],
  deals: [
    {id:'d1',date:new Date().toISOString().slice(0,10),type:'income',vehicleId:'v222',amount:200000,note:'Разница после обратного выкупа W222'}
  ]
};
let state = load();
let currentFilter = 'all';

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const money = n => '$' + Math.round(Number(n)||0).toLocaleString('ru-RU');
const uid = p => p + Date.now().toString(36) + Math.random().toString(36).slice(2,7);
const statusName = s => ({available:'Свободна',rented:'В аренде',sale:'На продаже',personal:'Личная'}[s]||s);
const vehicle = id => state.vehicles.find(v=>v.id===id);

function load(){try{return {...structuredClone(seed),...JSON.parse(localStorage.getItem(STORAGE_KEY))}}catch{return structuredClone(seed)}}
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(state));renderAll()}
function img(v,cls=''){return v?.photo?`<img class="${cls}" src="${v.photo}" alt="${v.name}">`:`<div class="car-placeholder ${cls}">${(v?.name||'AUTO').split(' ').slice(-1)[0].slice(0,3).toUpperCase()}</div>`}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}

function renderAll(){
  const fleetValue=state.vehicles.reduce((s,v)=>s+(+v.market||+v.purchase||0),0);
  const rentIncome=state.deals.filter(d=>d.type==='income'&&/аренд/i.test(d.note)).reduce((s,d)=>s+(+d.amount||0),0);
  $('#headerCash').textContent=money(state.cash);
  $('#stats').innerHTML=[
    ['Свободный баланс',money(state.cash),'Доступно для новых сделок','rgba(47,212,167,.14)'],
    ['Стоимость автопарка',money(fleetValue),`${state.vehicles.length} автомобилей`,'rgba(91,140,255,.14)'],
    ['Активные аренды',state.rentals.length,`${money(rentIncome)} заработано`,'rgba(255,189,89,.14)'],
    ['Потенциал прибыли',money(state.vehicles.reduce((s,v)=>s+Math.max(0,(+v.market||0)-(+v.purchase||0)),0)),'По текущей оценке','rgba(139,92,246,.15)']
  ].map(x=>`<div class="stat" style="--glow:${x[3]}"><span class="stat-label">${x[0]}</span><strong>${x[1]}</strong><small>${x[2]}</small></div>`).join('');
  renderGarage();renderRentals();renderDeals();renderDashboard();fillVehicleSelects();
}

function renderDashboard(){
  $('#vehicleStrip').innerHTML=state.vehicles.slice(0,4).map(v=>`<div class="mini-car"><span class="status ${v.status}">${statusName(v.status)}</span>${img(v)}<div class="mini-body"><b>${v.name}</b><small>${money(v.market||v.purchase)}</small></div></div>`).join('')||'<div class="empty">Добавьте первую машину</div>';
  $('#dashboardRentals').innerHTML=state.rentals.slice(0,3).map(r=>rentalMini(r)).join('')||'<div class="empty">Сейчас все машины свободны</div>';
  const deals=[...state.deals].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);
  $('#recentActivity').innerHTML=deals.map(d=>`<div class="activity"><small>${d.date}</small><span>${dealType(d.type)}</span><b>${vehicle(d.vehicleId)?.name||'Без автомобиля'}</b><strong class="amount ${['income','sale'].includes(d.type)?'positive':'negative'}">${['income','sale'].includes(d.type)?'+':'−'}${money(d.amount)}</strong></div>`).join('')||'<div class="empty">Операций пока нет</div>';
}

function renderGarage(){
  const q=$('#garageSearch')?.value?.toLowerCase()||'';
  const list=state.vehicles.filter(v=>(currentFilter==='all'||v.status===currentFilter)&&(`${v.name} ${v.plate}`.toLowerCase().includes(q)));
  $('#garageGrid').innerHTML=list.map(v=>`<article class="car-card"><span class="status ${v.status}">${statusName(v.status)}</span>${img(v)}<div class="car-body"><div class="car-title"><div><b>${v.name}</b><small>${v.plate||'Без номера'}</small></div><span class="car-value">${money(v.market||v.purchase)}</span></div><div class="car-metrics"><div class="metric"><small>ПОКУПКА</small><b>${money(v.purchase)}</b></div><div class="metric"><small>ПОТЕНЦИАЛ</small><b>${money((v.market||v.purchase)-v.purchase)}</b></div><div class="metric"><small>СВАЛКА</small><b>${money(v.scrap)}</b></div><div class="metric"><small>ЗАМЕТКА</small><b>${v.note||'—'}</b></div></div><div class="ad-preview">${v.advert||'Шаблон объявления не заполнен'}</div><div class="card-actions"><button class="copy-action" data-copy-ad="${v.id}" ${v.advert?'':'disabled'}>Копировать объявление</button><button data-rent="${v.id}" ${v.status==='rented'?'disabled':''}>В аренду</button><button data-edit-car="${v.id}">Изменить</button><button class="danger" data-delete-car="${v.id}">Удалить</button></div></div></article>`).join('')||'<div class="empty">Ничего не найдено</div>';
}

function rentalMini(r){const v=vehicle(r.vehicleId);const pct=Math.max(0,Math.min(100,(r.end-Date.now())/(r.end-r.start)*100));return `<div class="rental-mini"><div class="row-between"><div><b>${v?.name||'Автомобиль'}</b><small> • ${r.renter}</small></div><span class="timer" data-end="${r.end}"></span></div><div class="progress"><i style="width:${pct}%"></i></div></div>`}
function renderRentals(){
  $('#rentalList').innerHTML=state.rentals.map(r=>{const v=vehicle(r.vehicleId);return `<article class="rental-card">${img(v,'rent-thumb')}<div><h3>${v?.name||'Автомобиль'}</h3><p>${r.renter} • ${money(r.price)} • залог ${money(r.deposit)}</p><div class="progress"><i style="width:${Math.max(0,Math.min(100,(r.end-Date.now())/(r.end-r.start)*100))}%"></i></div></div><div class="rental-actions"><span class="timer" data-end="${r.end}"></span><button data-extend="${r.id}">+24 часа</button><button data-return="${r.id}">Вернулась</button></div></article>`}).join('')||'<div class="empty">Активных аренд нет</div>';
  $('#rentalHistory').innerHTML=state.rentalHistory.slice().reverse().slice(0,12).map(r=>`<div class="history-item"><div class="row-between"><b>${r.vehicleName}</b><strong class="amount positive">+${money(r.price)}</strong></div><small>${r.renter} • ${new Date(r.returned).toLocaleString('ru-RU')}</small></div>`).join('')||'<div class="empty">История пока пустая</div>';
}

function dealType(t){return({income:'Доход',expense:'Расход',purchase:'Покупка',sale:'Продажа'}[t]||t)}
function renderDeals(){
  const inc=state.deals.filter(d=>['income','sale'].includes(d.type)).reduce((s,d)=>s+(+d.amount||0),0);
  const out=state.deals.filter(d=>['expense','purchase'].includes(d.type)).reduce((s,d)=>s+(+d.amount||0),0);
  $('#dealSummary').innerHTML=`<div class="deal-chip"><small>Доходы</small><b class="amount positive">${money(inc)}</b></div><div class="deal-chip"><small>Расходы</small><b class="amount negative">${money(out)}</b></div><div class="deal-chip"><small>Результат</small><b>${money(inc-out)}</b></div>`;
  $('#dealTable').innerHTML=state.deals.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(d=>`<tr><td>${d.date}</td><td>${dealType(d.type)}</td><td>${vehicle(d.vehicleId)?.name||'—'}</td><td>${d.note||'—'}</td><td class="amount ${['income','sale'].includes(d.type)?'positive':'negative'}">${['income','sale'].includes(d.type)?'+':'−'}${money(d.amount)}</td><td><button class="icon-btn danger" data-delete-deal="${d.id}">×</button></td></tr>`).join('');
}

function fillVehicleSelects(){
  $('#dealVehicle').innerHTML='<option value="">Без автомобиля</option>'+state.vehicles.map(v=>`<option value="${v.id}">${v.name}</option>`).join('');
  $('#rentalCarPicker').innerHTML=state.vehicles.filter(v=>v.status!=='rented').map(v=>`<button type="button" class="pick-car" data-pick="${v.id}">${img(v)}<b>${v.name}</b></button>`).join('')||'<div class="empty">Нет свободных машин</div>';
}

function updateTimers(){
  $$('[data-end]').forEach(el=>{const ms=+el.dataset.end-Date.now();if(ms<=0){el.textContent='Просрочено';el.style.color='var(--red)';return}const h=Math.floor(ms/36e5),m=Math.floor(ms%36e5/6e4),s=Math.floor(ms%6e4/1000);el.textContent=`${h}ч ${String(m).padStart(2,'0')}м ${String(s).padStart(2,'0')}с`});
}

function openRental(id){fillVehicleSelects();const form=$('#rentalForm');form.reset();form.vehicleId.value=id||'';$$('.pick-car').forEach(b=>b.classList.toggle('selected',b.dataset.pick===id));syncRentalAd();$('#rentalDialog').showModal()}
function syncRentalAd(){const v=vehicle($('#rentalForm').vehicleId.value);$('#rentalAdBox span').textContent=v?.advert||'У выбранной машины пока нет шаблона';$('#copyRentalAd').disabled=!v?.advert}
async function copyAdvert(id){const text=vehicle(id)?.advert;if(!text)return toast('Сначала добавьте текст объявления');try{await navigator.clipboard.writeText(text);toast('Объявление скопировано')}catch{toast('Не удалось скопировать текст')}}
function openVehicle(v){const f=$('#vehicleForm');f.reset();$('#vehicleDialogTitle').textContent=v?'Изменить автомобиль':'Добавить автомобиль';f.editId.value=v?.id||'';f.name.value=v?.name||'';f.plate.value=v?.plate||'';f.purchase.value=v?.purchase||'';f.market.value=v?.market||'';f.scrap.value=v?.scrap||'';f.status.value=v?.status||'available';f.note.value=v?.note||'';f.advert.value=v?.advert||'';$('#photoData').value=v?.photo||'';$('#photoPreview').innerHTML=v?.photo?`<img src="${v.photo}" alt="Фото автомобиля">`:'<span>＋</span><b>Выбрать фотографию</b><small>PNG или JPG</small>';$('#vehicleDialog').showModal()}

$('#nav').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(!b)return;$$('.nav-item').forEach(x=>x.classList.toggle('active',x===b));$$('.view').forEach(v=>v.classList.remove('active'));$(`#${b.dataset.view}View`).classList.add('active');$('#viewTitle').textContent=({dashboard:'Добрый вечер, Саша',garage:'Ваш автопарк',rentals:'Центр аренды',deals:'Финансовый журнал',photos:'Редактор фотографий'}[b.dataset.view])});
document.addEventListener('click',e=>{const jump=e.target.closest('[data-jump]');if(jump)$(`.nav-item[data-view="${jump.dataset.jump}"]`).click();const rent=e.target.closest('[data-rent]');if(rent&&!rent.disabled)openRental(rent.dataset.rent);const edit=e.target.closest('[data-edit-car]');if(edit)openVehicle(vehicle(edit.dataset.editCar));const copy=e.target.closest('[data-copy-ad]');if(copy&&!copy.disabled)copyAdvert(copy.dataset.copyAd);const del=e.target.closest('[data-delete-car]');if(del&&confirm('Удалить автомобиль из гаража?')){state.vehicles=state.vehicles.filter(v=>v.id!==del.dataset.deleteCar);save()}const ret=e.target.closest('[data-return]');if(ret)returnRental(ret.dataset.return);const ext=e.target.closest('[data-extend]');if(ext){const r=state.rentals.find(x=>x.id===ext.dataset.extend);r.end+=864e5;save();toast('Аренда продлена на 24 часа')}const dd=e.target.closest('[data-delete-deal]');if(dd&&confirm('Удалить операцию?')){state.deals=state.deals.filter(d=>d.id!==dd.dataset.deleteDeal);save()}});
$('#garageSearch').addEventListener('input',renderGarage);$('#garageFilter').addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;currentFilter=b.dataset.filter;$$('#garageFilter button').forEach(x=>x.classList.toggle('active',x===b));renderGarage()});
['#quickAdd','#addVehicleBtn'].forEach(s=>$(s).addEventListener('click',()=>openVehicle()));
$('#photoPreview').addEventListener('click',()=>$('#vehiclePhoto').click());$('#vehiclePhoto').addEventListener('change',e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{$('#photoData').value=r.result;$('#photoPreview').innerHTML=`<img src="${r.result}" alt="Фото автомобиля">`};r.readAsDataURL(f)});
$('#vehicleForm').addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));if(d.editId){Object.assign(vehicle(d.editId),{name:d.name,plate:d.plate,purchase:+d.purchase,market:+d.market||+d.purchase,scrap:+d.scrap||0,status:d.status,photo:$('#photoData').value,note:d.note,advert:d.advert});toast('Карточка обновлена')}else{state.vehicles.push({id:uid('v'),name:d.name,plate:d.plate,purchase:+d.purchase,market:+d.market||+d.purchase,scrap:+d.scrap||0,status:d.status,photo:$('#photoData').value,note:d.note,advert:d.advert});state.cash-=+d.purchase;state.deals.push({id:uid('d'),date:new Date().toISOString().slice(0,10),type:'purchase',vehicleId:state.vehicles.at(-1).id,amount:+d.purchase,note:'Покупка автомобиля'});toast('Автомобиль добавлен')}$('#vehicleDialog').close();save()});
$('#newRentalBtn').addEventListener('click',()=>openRental());$('#rentalCarPicker').addEventListener('click',e=>{const b=e.target.closest('[data-pick]');if(!b)return;$('#rentalForm').vehicleId.value=b.dataset.pick;$$('.pick-car').forEach(x=>x.classList.toggle('selected',x===b));syncRentalAd()});$('#copyRentalAd').addEventListener('click',()=>copyAdvert($('#rentalForm').vehicleId.value));
$('#rentalForm').addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));if(!d.vehicleId)return toast('Сначала выберите автомобиль');const start=Date.now();state.rentals.push({id:uid('r'),vehicleId:d.vehicleId,renter:d.renter,price:+d.price,hours:+d.hours,deposit:+d.deposit,note:d.note,start,end:start+(+d.hours*36e5)});vehicle(d.vehicleId).status='rented';$('#rentalDialog').close();save();toast('Аренда запущена')});
function returnRental(id){const r=state.rentals.find(x=>x.id===id);if(!r)return;const v=vehicle(r.vehicleId);if(v)v.status='available';state.rentalHistory.push({...r,vehicleName:v?.name||'Автомобиль',returned:Date.now()});state.deals.push({id:uid('d'),date:new Date().toISOString().slice(0,10),type:'income',vehicleId:r.vehicleId,amount:r.price,note:`Аренда: ${r.renter}`});state.cash+=r.price;state.rentals=state.rentals.filter(x=>x.id!==id);save();toast('Машина возвращена, доход записан')}
$('#newDealBtn').addEventListener('click',()=>{$('#dealForm').reset();$('#dealForm').date.value=new Date().toISOString().slice(0,10);$('#dealDialog').showModal()});$('#dealForm').addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));state.deals.push({id:uid('d'),...d,amount:+d.amount});state.cash+=['income','sale'].includes(d.type)?+d.amount:-d.amount;$('#dealDialog').close();save();toast('Операция добавлена')});
$('#exportBtn').addEventListener('click',async()=>{const text=JSON.stringify(state,null,2);if(window.desktop)await window.desktop.saveBackup(text);else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'application/json'}));a.download='memphis-fleet.json';a.click()}toast('Резервная копия сохранена')});
$('#importBtn').addEventListener('click',async()=>{let text=window.desktop?await window.desktop.openBackup():null;if(!text)return;try{state=JSON.parse(text);save();toast('База восстановлена')}catch{toast('Не удалось прочитать файл')}});

const cropCanvas=$('#cropCanvas'),cropCtx=cropCanvas.getContext('2d');
let cropImage=null,cropRect=null,cropStart=null,cropDataUrl='';
function loadCropFile(file){if(!file||!file.type.startsWith('image/'))return toast('Выберите изображение');const reader=new FileReader();reader.onload=()=>{const image=new Image();image.onload=()=>{cropImage=image;const maxW=1000,maxH=625,scale=Math.min(maxW/image.width,maxH/image.height,1);cropCanvas.width=Math.round(image.width*scale);cropCanvas.height=Math.round(image.height*scale);const pad=.08;cropRect={x:cropCanvas.width*pad,y:cropCanvas.height*pad,w:cropCanvas.width*(1-pad*2),h:cropCanvas.height*(1-pad*2)};$('#cropEmpty').classList.add('hidden');cropCanvas.classList.add('ready');drawCrop();refreshCropOutput()};image.src=reader.result};reader.readAsDataURL(file)}
function drawCrop(){if(!cropImage)return;cropCtx.clearRect(0,0,cropCanvas.width,cropCanvas.height);cropCtx.drawImage(cropImage,0,0,cropCanvas.width,cropCanvas.height);cropCtx.fillStyle='rgba(3,5,9,.58)';cropCtx.fillRect(0,0,cropCanvas.width,cropCanvas.height);cropCtx.save();cropCtx.beginPath();cropCtx.rect(cropRect.x,cropRect.y,cropRect.w,cropRect.h);cropCtx.clip();cropCtx.drawImage(cropImage,0,0,cropCanvas.width,cropCanvas.height);cropCtx.restore();cropCtx.strokeStyle='#a78bfa';cropCtx.lineWidth=3;cropCtx.strokeRect(cropRect.x,cropRect.y,cropRect.w,cropRect.h)}
function canvasPoint(e){const box=cropCanvas.getBoundingClientRect();return{x:(e.clientX-box.left)*cropCanvas.width/box.width,y:(e.clientY-box.top)*cropCanvas.height/box.height}}
cropCanvas.addEventListener('pointerdown',e=>{if(!cropImage)return;cropStart=canvasPoint(e);cropRect={x:cropStart.x,y:cropStart.y,w:1,h:1};cropCanvas.setPointerCapture(e.pointerId)});
cropCanvas.addEventListener('pointermove',e=>{if(!cropStart)return;const p=canvasPoint(e),ratio=+$('#cropRatio').value;let w=p.x-cropStart.x,h=p.y-cropStart.y;if(ratio){const signY=Math.sign(h)||1;h=Math.abs(w)/ratio*signY}cropRect={x:Math.max(0,Math.min(cropStart.x,cropStart.x+w)),y:Math.max(0,Math.min(cropStart.y,cropStart.y+h)),w:Math.min(Math.abs(w),cropCanvas.width-Math.max(0,Math.min(cropStart.x,cropStart.x+w))),h:Math.min(Math.abs(h),cropCanvas.height-Math.max(0,Math.min(cropStart.y,cropStart.y+h)))};drawCrop()});
cropCanvas.addEventListener('pointerup',()=>{cropStart=null;refreshCropOutput()});
function makeCrop(){if(!cropImage||!cropRect||cropRect.w<5||cropRect.h<5)return null;const sourceScale=cropImage.width/cropCanvas.width;const out=document.createElement('canvas'),outW=+$('#cropWidth').value,outH=Math.round(outW*(cropRect.h/cropRect.w));out.width=outW;out.height=outH;out.getContext('2d').drawImage(cropImage,cropRect.x*sourceScale,cropRect.y*sourceScale,cropRect.w*sourceScale,cropRect.h*sourceScale,0,0,outW,outH);const format=$('#cropFormat').value,quality=+$('#cropQuality').value/100;return{data:out.toDataURL(format,quality),format,width:outW,height:outH}}
function refreshCropOutput(){const result=makeCrop();if(!result)return;cropDataUrl=result.data;const bytes=Math.round((result.data.length-result.data.indexOf(',')-1)*.75);$('#cropSize').textContent=`${result.width}×${result.height} • ${bytes>1048576?(bytes/1048576).toFixed(2)+' МБ':Math.round(bytes/1024)+' КБ'}`;$('#saveCrop').disabled=false;$('#useCropAsPhoto').disabled=false}
$('#openCropImage').addEventListener('click',()=>$('#cropFile').click());$('#cropFile').addEventListener('change',e=>loadCropFile(e.target.files[0]));
const cropStage=$('.crop-stage');['dragenter','dragover'].forEach(x=>cropStage.addEventListener(x,e=>{e.preventDefault();cropStage.classList.add('drag')}));['dragleave','drop'].forEach(x=>cropStage.addEventListener(x,e=>{e.preventDefault();cropStage.classList.remove('drag')}));cropStage.addEventListener('drop',e=>loadCropFile(e.dataTransfer.files[0]));
['cropFormat','cropWidth','cropRatio'].forEach(id=>$(`#${id}`).addEventListener('change',refreshCropOutput));$('#cropQuality').addEventListener('input',e=>{$('#qualityValue').textContent=e.target.value+'%';refreshCropOutput()});
$('#saveCrop').addEventListener('click',async()=>{const result=makeCrop();if(!result)return;if(window.desktop){const path=await window.desktop.saveImage({base64:result.data,format:result.format,filename:'majestic-car-'+Date.now()});if(path)toast('Фотография сохранена')}else{const a=document.createElement('a');a.href=result.data;a.download='majestic-car.jpg';a.click()}});
$('#useCropAsPhoto').addEventListener('click',()=>{if(!cropDataUrl)return;openVehicle();$('#photoData').value=cropDataUrl;$('#photoPreview').innerHTML=`<img src="${cropDataUrl}" alt="Фото автомобиля">`;toast('Фото перенесено в карточку')});

setInterval(updateTimers,1000);renderAll();updateTimers();
